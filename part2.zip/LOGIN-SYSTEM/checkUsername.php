<?php
    include("../database-connection/connect.php");
    $rows = $db->query("select user_name from `user`;");
    $usernames = array();
    foreach ($rows as $key => $value) {
        array_push($usernames, $value["user_name"]);
    }
    if (isset($_POST["username"])) {
        if (in_array($_POST["username"], $usernames)) {
            echo "invalid";
        }
        else{
            echo "valid";
        }
    }
    
    

?>