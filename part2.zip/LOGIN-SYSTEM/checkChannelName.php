<?php
    include("../database-connection/connect.php");
    $rows = $db->query("select channel_name from `channel`;");
    $channelsNames = array();
    foreach ($rows as $key => $value) {
        array_push($channelsNames, $value["channel_name"]);
    }
    if (isset($_POST["channelName"])) {
        if (in_array($_POST["channelName"], $channelsNames)) {
            echo "invalid";
        }
        else{
            echo "valid";
        }
    }
    
    

?>