<?php
    include("../database-connection/connect.php");
    $error="";
    $errorContent="";
    if (isset($_GET["logout"])) {
        session_start();
        session_destroy();
    }
    if (isset($_POST["signup-submit"])) {   
        $rows = $db->query("select * from `channel` where channel_name='". $_POST["channel-name"] ."';");
        $rows1 = $db->query("select * from `user` where user_name='". $_POST["username"] ."';");
        if ($rows->rowCount()>0) {
            $error = "class=\"alert alert-warning alert-dismissible fade in\" id=\"alert\" style=\"text-align: center; position: fixed; top:0; display: block; width: 300px\"";
            $errorContent = "<a href=\"#\" class=\"close\" data-dismiss=\"alert\" aria-label=\"close\">&times;</a><strong>This Channel Name is Already Taken!</strong>";
        }
        elseif($rows1->rowCount()>0){
            $error = "class=\"alert alert-warning alert-dismissible fade in\" id=\"alert\" style=\"text-align: center; position: fixed; top:0; display: block width: 300px\"";
            $errorContent = "<a href=\"#\" class=\"close\" data-dismiss=\"alert\" aria-label=\"close\">&times;</a><strong>This Username is Already Taken!</strong>";
        }
        else{
            $channelName = $db->quote($_POST["channel-name"]);
            $username = $db->quote($_POST["username"]);
            $pass = $db->quote($_POST["password"]);
            $addUser = "Insert INTO `user` (`user_name`, `user_password`) VALUES ($username, $pass);";
            $db->exec($addUser);
            $last_id = $db->lastInsertId();
            $hash_password = $db->quote($_POST["password"]);
            $updateUserPass = "UPDATE `user` set user_password= $hash_password where user_id = $last_id";
            $db->exec($updateUserPass);
            $addChannel = "Insert INTO `channel` (`author`, `profile_pic`, `channel_name`) VALUES ($username,  '../profiles/defaultImageForAllUsers.png', $channelName);";
            $db->exec($addChannel);
            session_start(); 
            $_SESSION["logged_in"] = $last_id;
            header("Location: ../MainPage/main.php");
        }
        
    }elseif(isset($_POST["login-submit"])){
        $username = $_POST["username"];
        $pass = $_POST["password"];   
        $rows = $db->query("select * from `user` where user_name='". $_POST["username"] ."';");
        if ($rows->rowCount()>0) {
            $result = $rows->fetch();
            $rows1 = $db->query("select * from `channel` where author='". $_POST["username"] ."';");
            $result1 = $rows1->fetch();
            if (strcmp($_POST["password"], $result["user_password"])==0) {
                if ($_POST["remember"] == "on") {
                    setcookie("remember-me", $_POST["remember"], time() + (365*24*60*60));
                    setcookie("username", $username, time() + (365*24*60*60));
                    setcookie("password", $pass, time() + (365*24*60*60));
                }else {
                    setcookie("remember-me", FALSE);
                    setcookie("username", FALSE);
                    setcookie("password", FALSE);
                }
                session_start();
                $_SESSION["logged_in"] = $result1["channel_user_id"];
                header("Location: ../MainPage/main.php");
            }else{
                $error = "class=\"alert alert-warning alert-dismissible fade in\" id=\"alert\" style=\"text-align: center; position: fixed; top:0; display: block; width: 300px\"";
            $errorContent = "<a href=\"#\" class=\"close\" data-dismiss=\"alert\" aria-label=\"close\">&times;</a><strong>Incorrect Password!</strong>";
            }

        }else{
            $error = "class=\"alert alert-warning alert-dismissible fade in\" id=\"alert\" style=\"text-align: center; position: fixed; top:0; display: block; width: 300px\"";
            $errorContent = "<a href=\"#\" class=\"close\" data-dismiss=\"alert\" aria-label=\"close\">&times;</a><strong>Incorrect Username!</strong>";
        }

    }


?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
	<script src="https://kit.fontawesome.com/64d58efce2.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="Login.css">
    <script>

    window.onload = function(){
        document.getElementById("check").className = '';
        document.getElementById("check1").className = '';
        document.getElementById("channelName").oninput = checkAvailability;
        document.getElementById("username").oninput = checkAvailability1;
        $(document).ready(function() {
            $("#alert").fadeTo(9000, 500).slideUp(500, function(){
            $("#alert").slideUp(500);
            });
        });
    }
    function checkAvailability(){
        let l = document.getElementById("channelName").value;
        document.getElementById("check").className = '';
        if(l.length>=3){
            $.ajax({
                url: 'checkChannelName.php',
                type: 'POST',
                data: { channelName: document.getElementById("channelName").value },
                success: function(data){
                    if (data == "valid") {
                        document.getElementById("check").className = '';
                        document.getElementById("check").classList.add("valid");
                    }else{
                        document.getElementById("check").className = '';
                        document.getElementById("check").classList.add("invalid");
                    }
                }
            });
        }
    }
    function checkAvailability1(){
        let l = document.getElementById("username").value;
        document.getElementById("check1").className = '';
        if(l.length>=3){
            $.ajax({
                url: 'checkUsername.php',
                type: 'POST',
                data: { username: document.getElementById("username").value },
                success: function(data){
                    if (data == "valid") {
                        document.getElementById("check1").className = '';
                        document.getElementById("check1").classList.add("valid");
                    }else{
                        document.getElementById("check1").className = '';
                        document.getElementById("check1").classList.add("invalid");
                    }
                }
            });
        }
    }
    
</script>

</head>
<body class="main">
    <div <?= $error ?>>
        <?= $errorContent ?>
    </div>
	<div class="c1">
		<div class="ls">
			<hr class="lines"><hr class="lines">
			<p style="margin: 20px 0; font-size: xx-large; font-weight: bold">SignUp</p>
			<form action="" method="POST">
				<div class="c2">
                    <i class="fas fa-chalkboard-teacher"></i>
                    <span id="check"></span>
					<input class="inputsFromUser" id="channelName" type="text" placeholder="Channel Name" name="channel-name" pattern=".{3,}" title="Three or more characters" required>
				</div>
				<div class="c2">
                    <i class="fas fa-user"></i>
                    <span id="check1"></span>
					<input class="inputsFromUser" id="username" type="text" placeholder="Username" name="username" pattern=".{3,}" title="Three or more characters" required>
				</div>
				<div class="c2">
					<i class="fas fa-key"></i>
					<input class="inputsFromUser" type="password" placeholder="Password" name="password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required>
                </div>
				<button class="AuthenticateButtons" type="submit" name="signup-submit">Signup</button>
			</form>

		</div>
		<div class="middle">
			OR
		</div>
		<div class="rs">
			<hr class="lines"><hr class="lines">
			<p style="margin: 20px 0; font-size: xx-large; font-weight: bold">LogIn</p>
			<form action="" method="POST">
				<div class="c2">
                    <i class="fas fa-user"></i>
					<input class="inputsFromUser" type="text" placeholder="Username" name="username" required="required" value="<?php if(isset($_COOKIE["remember-me"])) {echo $_COOKIE["username"];} ?>">
				</div>
				<div class="c2">
					<i class="fas fa-key"></i>
					<input class="inputsFromUser" type="password" placeholder="Password" name="password"  required="required" value="<?php if(isset($_COOKIE["remember-me"])) {echo $_COOKIE["password"];} ?>">
                </div>
                <div class="clearfix c2">
                    <label class="float-left form-check-label"><input type="checkbox" name="remember" <?php if(isset($_COOKIE["remember-me"])) {echo "checked";} ?>> Remember me</label>
                </div> 
				<button class="AuthenticateButtons" type="submit" name="login-submit">Login</button>
			</form>
			
		</div>
	</div>
</body>
</html>