<?php
    session_start();
    if (!isset($_SESSION["logged_in"])) {
        header("Location: ../MainPage/main.php");
    }
    include("../database-connection/connect.php");
    $id = $_SESSION["logged_in"];
    $result = "select * from `channel` where channel_user_id= $id LIMIT 1;";
    $result = $db->query($result);
    $UserData = $result->fetch();
    $videos = $db->query("select * from `videos` where channel_id= $id;");

    $result1 = "SELECT `playlist` from `channel` where channel_user_id= $id LIMIT 1;";
    $result1 = $db->query($result1);
    $UserData1 = $result1->fetch();
    $list_of_Videos = explode("|", $UserData1["playlist"]);
?>
<!DOCTYPE html>
<html>

<head>
    <title> Your channel page</title>
    <link href="channel.css" rel="stylesheet" type="text/css" />
    <link href='http://fonts.googleapis.com/css?family=Roboto' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
    <input type="hidden" id="userId" value="<?= $UserData["channel_name"] ?>">
    <header class="header">
        <div class="container1">
            <div class="profile-container">
                    <p>
                        <img class="menu-channel-icon" src="<?= $UserData["profile_pic"] == null? "../profiles/defaultImageForAllUsers.png" : $UserData["profile_pic"] ?>" onclick="file_explorer();"   alt="your channel">
                    </p>
                    <input type="file" accept="image/*" id="select-file">
                    <p id="channelName"><?= $UserData["channel_name"] ?></p>
            </div>
            <div class="btns-container">
                <a href="../MainPage/main.php" class="btn1">home</a>
                <a href="../upload-page/upload-video-page.php?userId=<?= $id ?>" class="btn2">manage videos</a>
            </div>
        </div>
        <div class="nav-bar">
            <a href="javascript:void(0)" class="tablink active" onclick="openPage('home', this)" id="defaultOpen">home</a>
            <a href="javascript:void(0)" class="tablink" onclick="openPage('videos', this)">videos</a>
            <a href="javascript:void(0)" class="tablink" onclick="openPage('playlist', this)">playlist</a>
            <a href="javascript:void(0)" class="tablink" onclick="openPage('channels', this)">channels</a>
            <a href="javascript:void(0)" class="tablink" onclick="openPage('discussion', this)">discussion</a>
            <a href="javascript:void(0)" class="tablink" onclick="openPage('about', this)">about</a>
            <a href="javascript:void(0)" onclick="searchForm()"><i class="fa fa-search"></i></a>
            <a href="javascript:void(0)" id="search-form">
                <form>
                    <div class="input_container">
                        <input type="text" class="awsome_input" placeholder="Search" />
                        <span class="awsome_input_border"></span>
                    </div>
                </form>
            </a>
        </div>
    </header>
    <div id="home" class="tabContent">
        <div id="in-home">
            <img src="empty_channel_illustration.svg" class="img" width="200px" height="200px">
            <h2>Upload a video to get started</h2>
            <p class="a">Start sharing your story and connecting with viewers. Videos you upload will show up here.</p>
            <a href="../upload-page/upload-video-page.php" class="upload_video">UPLOAD VIDEO</a>
        </div>
    </div>
    <div id="videos" class="tabContent">
        <div class="channel-videos">
            <?php
                foreach ($videos as $key => $value) { ?>
                <div class="inner-channel-video"  >
                    <div>
                        <video width="300px" height="200px" controls>
                            <source src="<?= $value["video_path"]?>">
                        </video>
                    </div>
                    <div style="width:300px"> 
                        <p style="font-weight: bolder; font-size:xx-large"><?= $value["title"] ?></p>
                        <?php 
                        $newdesc = "";
                        if(strlen($value["description"])>30){
                            for ($i=0; $i < 30; $i++) { 
                                $newdesc .= $value["description"][$i];
                            } ?>
                            <p><?= $newdesc . "..." ?></p>
                    <?php    }else{ ?>
                            <p><?= $value["description"] ?></p>

                <?php    }  ?>
                        
                    </div>
                    <div>
                        <button id="<?= $value["video_id"]?>" onclick="javascript: location.href = '../MainPage/watchFolder/watching_video.php?vid='+this.id" class="btn1">OPEN VIDEO</button>
                    </div>
                </div>
                
                   
            <?php    }
            ?>
        </div>
    </div>
    <div id="playlist" class="tabContent">
    <div class="channel-videos">
        <?php
                for ($i=1; $i < count($list_of_Videos); $i++) { 
                    // echo $l[$i];
                    $video = $db->query("SELECT * FROM `videos` where `video_id`= $list_of_Videos[$i] and `show`=1;"); 
                    $value = $video->fetch();
                    $vid = $value["video_id"];

        ?>
        <div class="inner-channel-video">
                    <div>
                        <video width="300px" height="200px" controls>
                            <source src="<?= $value["video_path"]?>">
                        </video>
                    </div>
                    <div>
                        <p style="font-weight: bolder; font-size:xx-large"><?= $value["title"] ?></p>
                        <?php 
                        $newdesc = "";
                        if(strlen($value["description"])>30){
                            for ($i=0; $i < 30; $i++) { 
                                $newdesc .= $value["description"][$i];
                            } ?>
                            <p><?= $newdesc . "..." ?></p>
                    <?php    }else{ ?>
                            <p><?= $value["description"] ?></p>

                <?php    }  ?>
                        
                    </div>
                    <div>
                        <button id="<?= $value["video_id"]?>" onclick="javascript: location.href = '../MainPage/watchFolder/watching_video.php?vid='+this.id" class="btn1">OPEN VIDEO</button>
                    </div>
                </div>
                
                   
            <?php    }
            ?>
        </div>
    </div>
    </div>
    <div id="channels" class="tabContent">
        <div>
            <p>channels div</p>
        </div>
    </div>
    <div id="discussion" class="tabContent">
        <div>
            <p>discussions div</p>
        </div>
    </div>
    <div id="about" class="tabContent">
        <div>
            <p>about div</p>
        </div>
    </div>
    <script>
        function file_explorer() {
            document.getElementById('select-file').click();
            document.getElementById('select-file').onchange = function() {
                filesObj = document.getElementById('select-file').files[0];
                ajax_file_upload(filesObj);
            };
        }
        function ajax_file_upload(file_obj) {
            if(file_obj != undefined) {
                var form_data = new FormData();                  
                form_data.append('file', file_obj);
                var x = document.getElementById("userId").value;
                form_data.append("userId", x)
                var ajax = new XMLHttpRequest();
                ajax.onreadystatechange = function(){
                    if(ajax.readyState==4 && ajax.status==200){
                        location.reload();
                    }
                };
                ajax.open("POST", "profile.php");
                ajax.send(form_data);
            }
        }
        function openPage(pageName, element) {
            var i, tabcontent, actives;
            tabcontent = document.getElementsByClassName("tabContent");
            for (i = 0; i < tabcontent.length; i++) {
                tabcontent[i].style.display = "none";
            }
            actives = document.getElementsByClassName("active");
            for (i = 0; i < actives.length; i++) {
                actives[i].classList.remove("active");
            }
            document.getElementById(pageName).style.display = "block";
            element.classList.add("active");
        }
        document.getElementById("defaultOpen").click();

        function searchForm() {
            if (document.getElementById("search-form").classList.contains("show")) {
                document.getElementById("search-form").style.display = "none";
                document.getElementById("search-form").classList.remove("show");
            } else {
                document.getElementById("search-form").style.display = "inline-block";
                document.getElementById("search-form").classList.add("show");
            }
        }
    </script>
</body>

</html>