<?php
    include("../database-connection/connect.php");
    move_uploaded_file($_FILES['file']['tmp_name'], '../profiles/' . time() . '_' . $_FILES['file']['name']);
    $imagePath = '../profiles/' . time() . '_' . $_FILES['file']['name'];
    if (isset($_POST["userId"])) {
        $db->exec("UPDATE `channel` set profile_pic= '$imagePath' where channel_name= '". $_POST["userId"] ."' limit 1;");
    }
?>