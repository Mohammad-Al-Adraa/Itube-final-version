<?php
    session_start();
    if (!isset($_SESSION["logged_in"])) {
        header("Location: ../MainPage/main.php");
    }
    include("../database-connection/connect.php");
    $id = $_SESSION["logged_in"];
    $result = "select * from `channel` where channel_user_id= $id LIMIT 1;";
    $result = $db->query($result);
    $UserData = $result->fetch();
    $videos = $db->query("select * from `videos` where channel_id= $id;");
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="keywords" content="ITube">
        <meta name="description" content="Have fun with our new app ITube. Best place to upload your videos.">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <meta http-equiv="cache-control" content="max-age=0" />
        <meta http-equiv="cache-control" content="no-cache" />
        <meta http-equiv="expires" content="0" />
        <meta http-equiv="pragma" content="no-cache" />
        <link rel="stylesheet" href="../MainPage/dropdowns.css">
        <link href='http://fonts.googleapis.com/css?family=Roboto' rel='stylesheet' type='text/css'>
        <link rel="stylesheet" href="upload-video-page.css">

        <title>ITube Studio</title>
        <link rel="icon" href="../MainPage/img-for-Home-page/Itube.jpg" type="image">
    </head>

<body>
    <input type="hidden" id="userId" value="<?= $UserData["channel_name"] ?>">
    <header id="upload-header">
        <div>
            <a href="../MainPage/main.php">
                <img src="../MainPage/img-for-Home-page/logo.jpg" alt="ITube logo" id="Itube-logo">
            </a>
        </div>
        <div id="c1-header">
            <button id="dropdown1">
                <img  src="../MainPage/img-for-Home-page/drp1.svg" alt="upload_video">
                <span >CREATE</span>
            </button>
            <div class="dropdown">
                <button id="dropdown2" class="dropbtn">    
                    <img  class="menu-channel-icon dropbtn" src="<?= $UserData["profile_pic"] == null? "../profiles/defaultImageForAllUsers.png" : $UserData["profile_pic"] ?>" alt="your channel">
                </button>
            </div>
        </div>
    </header>
    <div id="upload-modal" class="modal">
        <div class="modal-content">
            <div class="c1-modal-content">
                <p>Upload videos</p>
                <span class="close">&times;</span>
            </div>
            <div class="c2-modal-content" ondrop="upload_file(event)">
                <div class="upload-btns-margin">
                    <form>
                        <label for="file" class="file-label">
                            <svg id="upc" class="upload-icon" xmlns="http://www.w3.org/2000/svg" enable-background="new 0 0 24 24" height="24" viewBox="0 0 24 24" width="24"><g><rect fill="none" height="24" width="24"/><path d="M16,18v2H8v-2H16z M11,7.99V16h2V7.99h3L12,4L8,7.99H11z"/></g></svg>
                        </label> <input type="file" id="file" name="file1" accept="video/*" multiple>
                    </form>
                </div>
                <div class="c3-modal-content">
                    <p>Drag and drop video files to upload</p>
                    <small>Your videos will be private until you publish them.</small>
                </div>
                <div class="upload-btns-margin">
                    <p><input type="button" id="btn-upload-design" value="Select File" onclick="file_explorer();"></p>
                    <input type="file" id="select-file" accept="video/*" multiple>
                </div>
            </div>
        </div>
    </div>
    <div id="progressModal" class="modal1">
        <!-- Modal content -->
        <div class="modal-content1">
            <div class="modal-header1">
            <span class="close">&times;</span>
            <h2>Download Progress</h2>
            </div>
            <div class="modal-body1">
                <div id="uploaded-progress">
                    <progress id="progressBar" value="0" max="100" style="width:300px;"></progress>
                    <h3 id="status"></h3>
                    <p id="loaded_n_total"></p>
                </div>
            </div>
            <div class="modal-footer1">
            </div>
        </div>
    </div>

    <div id="main">
        <table id="data-table">
            <tr>
                <th>Video</th>
                <th>Visibility</th>
                <th>Date</th>
                <th>Views</th>
                <th>#Comments</th>
                <th>Likes</th>
                <th>Dislikes</th>
            </tr>
            <?php
                foreach ($videos as $key => $value) { ?>
                    <tr>
                        <td>
                            <div id="td-video">
                                <div class="video-design">
                                    <video width="250px" height="200px" controls>
                                        <source src="<?= $value["video_path"]?>">
                                    </video>
                                </div>
                                <div class="title-description">
                                    <a href="videoDetails.php?videoId=<?= $value["video_id"] ?>" class="btns">DETAILS</a>
                                    <a href="DeleteVideo.php?videoId=<?= $value["video_id"] ?>" class="btns" onclick="javascript: return confirm('Are you Sure you want to delete this Video permanently?')">DELETE</a>
                                </div>
                            </div>
                            
                        </td>
                        <td>
                            <button class="btns" value="<?= $value["video_id"] ?>" id="showOrHide<?= $value["video_id"] ?>" onclick="private(this.id);"><?= ($value["show"] == '1')? "Hide" : "Show" ?></button>
                        </td>
                        <td><?= $value["date"] ?></td>
                        <td><?= $value["views"]?></td>
                        <?php
                            $q = $db->query("SELECT COUNT(comment) as NumOfc from `comments` where `video_id`= '".$value["video_id"]."'");
                            $NumberOfComments = $q->fetch();
                        ?>
                        <td><?= $NumberOfComments["NumOfc"] ?></td>
                        <td><?= $value["likes"]  ?></td>
                        <td><?= $value["dislikes"] ?></td>
                    </tr>
            <?php    } ?>
            

        </table>
    
    </div>

    <div id="showdrp1" class="dropdown-content">
        <div class="grouped-icon">
            <div class="Container edited">
                <img class="menu-channel-icon" src="<?= $UserData["profile_pic"] == null? "../profiles/defaultImageForAllUsers.png" : $UserData["profile_pic"] ?>" alt="your channel">
                <div>
                    <p><?= $UserData["author"] ?></p>
                    <p><?= $UserData["channel_name"] ?></p>
                </div>
            </div>
        </div>
        <div class="grouped-icon">
            <a href="../channel/channel.php" class="Container">
                <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M0 0h24v24H0z" fill="none"/><path d="M3 5v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2H5c-1.11 0-2 .9-2 2zm12 4c0 1.66-1.34 3-3 3s-3-1.34-3-3 1.34-3 3-3 3 1.34 3 3zm-9 8c0-2 4-3.1 6-3.1s6 1.1 6 3.1v1H6v-1z"/></svg>
                <p>Your channel</p>
            </a>
            <a href="../LOGIN-SYSTEM/Login.php?logout=true" class="Container">
                <svg version="1.1" id="Capa_1" height="20" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 384 384" style="enable-background:new 0 0 384 384;" xml:space="preserve">
                    <g>
                        <g>
                            <g>
                                <path d="M341.333,0H42.667C19.093,0,0,19.093,0,42.667V128h42.667V42.667h298.667v298.667H42.667V256H0v85.333
                                    C0,364.907,19.093,384,42.667,384h298.667C364.907,384,384,364.907,384,341.333V42.667C384,19.093,364.907,0,341.333,0z"/>
                                <polygon points="151.147,268.48 181.333,298.667 288,192 181.333,85.333 151.147,115.52 206.293,170.667 0,170.667 0,213.333 
                                    206.293,213.333 			"/>
                            </g>
                        </g>
                    </g>
                    <g>
                    </g>
                    <g>
                    </g>
                    <g>
                    </g>
                    <g>
                    </g>
                    <g>
                    </g>
                    <g>
                    </g>
                    <g>
                    </g>
                    <g>
                    </g>
                    <g>
                    </g>
                    <g>
                    </g>
                    <g>
                    </g>
                    <g>
                    </g>
                    <g>
                    </g>
                    <g>
                    </g>
                    <g>
                    </g>
                </svg>
                <p>Sign out</p>
            </a>
        </div>
        <div class="grouped-icon">
            <a href="" class="Container">
                <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M0 0h24v24H0z" fill="none"/><path d="M20 2H4c-1.1 0-1.99.9-1.99 2L2 22l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-7 12h-2v-2h2v2zm0-4h-2V6h2v4z"/></svg>
                <p>Send feedback</p>
            </a>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="upload-video-page.js"></script>
</body>

</html>