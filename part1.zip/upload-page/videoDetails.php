<?php
    $videoDetails = null;
    $author = null;
    include("../database-connection/connect.php");
    if (isset($_REQUEST["videoId"])) {
        $id = $_REQUEST["videoId"];
        $videoDetails = $db->query("SELECT `dislikes`, `title`, `likes`, `description`, `date`, `video_id`, `channel_id`, `video_path`, `views` FROM `videos` WHERE `video_id`=$id;");
        $videoDetails = $videoDetails->fetch();
        $author = $db->query("SELECT `author` from `channel` where channel_user_id= '". $videoDetails["channel_id"] ."';");
        $author = $author->fetch();
    }if(isset($_POST["submit"])){
        $id = $_REQUEST["videoId"];
        $q = "UPDATE `videos` SET `title`= '". $_POST["title"] ."', `description`= '". $_POST["desc"] ."' WHERE `video_id`=$id ;";
        $db->exec($q);
        header("Location: videoDetails.php?videoId=$id&updated=true");
    }if(isset($_REQUEST["videoId"]) && isset($_REQUEST["updated"])){
        echo "<div class=\"alert alert-success alert-dismissible fade in\" id=\"alert\" style=\"text-align: center;\">
        <a href=\"#\" class=\"close\" data-dismiss=\"alert\" aria-label=\"close\">&times;</a>
        <strong>Updated successfully!!</strong>
        </div>";
    }



?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <title>Document</title>
    <script>
        $(document).ready(function() {
            $("#alert").fadeTo(2000, 500).slideUp(500, function(){
            $("#alert").slideUp(500);
            });
            setTimeout(fetchdata,1000);
        });
    </script>
</head>
<body style="padding-left: 10px;">
    <a href="upload-video-page.php">GO BACK</a>
    <h2>Edit Video's Details: </h2>
    <form action="" method="post">
        <label for="title">Author:</label><br>
        <input type="text" name="author" id="author" value="<?= $author["author"] ?>" readonly><br><br>
        <label for="title">Title:</label><br>
        <textarea name="title" id="title" cols="30" rows="10"><?= $videoDetails["title"] ?></textarea><br><br>
        <label for="desc">Description:</label><br>
        <textarea name="desc" id="desc" cols="30" rows="10"><?= $videoDetails["description"] ?></textarea><br><br>
        <input type="submit" value="CHANGE" name="submit">
    </form>
</body>
</html>