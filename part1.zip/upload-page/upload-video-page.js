function _(el) {
    return document.getElementById(el);
}
var fileobj;
window.onload = function() {
    var modal = document.getElementById("upload-modal");
    var modal1 = document.getElementById("progressModal");

    window.addEventListener("click", function(event) {
        if (!event.target.matches('.dropbtn')) {
            var dropdowns = document.getElementsByClassName("dropdown-content");
            var i;
            for (i = 0; i < dropdowns.length; i++) {
                var openDropdown = dropdowns[i];
                if (openDropdown.classList.contains('show')) {
                    openDropdown.classList.remove('show');
                }
            }
        }
        if (event.target == modal) {
            modal.style.display = "none";
        } else if (event.target == modal1) {
            modal1.style.display = "none";
            location.reload();
        }
    });
    document.getElementById('file').onchange = function() {
        filesObj = document.getElementById('file').files;
        $("#upload-modal").css("display", "none");
        $("#progressModal").css("display", "block");
        ajax_file_upload(filesObj);
    };

    document.getElementById("dropdown2").onclick = drp2;

    var btn = document.getElementById("dropdown1");

    var span = document.getElementsByClassName("close")[0];
    var span1 = document.getElementsByClassName("close")[1];


    btn.onclick = function() {
        modal.style.display = "block";
    }

    span.onclick = function() {
        modal.style.display = "none";
    }
    span1.onclick = function() {
        modal1.style.display = "none";
        location.reload();
    }

    $(document).ready(function() {
        $(".c2-modal-content").on('dragover', function() {
            $("#upc").css("fill", "blue");
            return false;
        });
        $('.c2-modal-content').on('dragleave', function() {
            $("#upc").css("fill", "#888");
            return false;
        });

    });

}



function drp2() {
    document.getElementById("showdrp1").classList.toggle("show");
}

var filesObj;

function file_explorer() {
    document.getElementById('select-file').click();
    document.getElementById('select-file').onchange = function() {
        filesObj = document.getElementById('select-file').files;
        $("#upload-modal").css("display", "none");
        $("#progressModal").css("display", "block");
        ajax_file_upload(filesObj);
    };
}

function upload_file(e) {
    e.preventDefault();
    $("#upc").css("fill", "#888");
    $("#upload-modal").css("display", "none");
    $("#progressModal").css("display", "block");
    ajax_file_upload(e.dataTransfer.files);
}


function ajax_file_upload(file_obj) {
    if (file_obj != undefined) {
        var form_data = new FormData();
        for (i = 0; i < file_obj.length; i++) {
            form_data.append('file[]', file_obj[i]);
        }
        var x = document.getElementById("userId").value;
        form_data.append("userId", x)
        var ajax = new XMLHttpRequest();
        // ajax.onreadystatechange = function() {
        //     if (ajax.readyState == 4 && ajax.status == 200) {
        //         alert(this.responseText);
        //     }
        // };
        ajax.upload.addEventListener("progress", progressHandler, false);
        ajax.addEventListener("load", completeHandler, false);
        ajax.addEventListener("error", errorHandler, false);
        ajax.addEventListener("abort", abortHandler, false);
        ajax.open("POST", "ajax.php");
        ajax.send(form_data);
    }
}



function progressHandler(event) {
    _("loaded_n_total").innerHTML = "Uploaded " + event.loaded + " bytes of " + event.total;
    var percent = (event.loaded / event.total) * 100;
    _("progressBar").value = Math.round(percent);
    _("status").innerHTML = Math.round(percent) + "% uploaded... please wait";
}

function completeHandler(event) {
    _("status").innerHTML = event.target.responseText;
    _("progressBar").value = 0;
}

function errorHandler(event) {
    _("status").innerHTML = "Upload Failed";
}

function abortHandler(event) {
    _("status").innerHTML = "Upload Aborted";
}

function private(btn_id) {
    var t = _(btn_id).innerText;
    if (t == "Hide") {
        $.ajax({
            type: "POST",
            url: "hide.php",
            data: { "private": _(btn_id).value },
            success: function(response) {
                _(btn_id).innerText = "Show";
            }
        });
    } else {
        $.ajax({
            type: "POST",
            url: "show.php",
            data: { "private": _(btn_id).value },
            success: function(response) {
                _(btn_id).innerText = "Hide";
            }
        });
    }
}