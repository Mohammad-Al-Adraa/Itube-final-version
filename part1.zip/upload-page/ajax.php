<?php
    if (!file_exists( '../uploads/'.$_POST["userId"])) {
        mkdir( '../uploads/'.$_POST["userId"], 0777);
    }
    include("../database-connection/connect.php");
    include_once('../getID3-master/getID3-master/getid3/getid3.php'); 
   
    foreach($_FILES['file']['name'] as $key=>$val){
        $file_name = $_FILES['file']['name'][$key];
        $title = "test";
        $dateUploaded = "2020-09-19";
        $id = $db->query("select channel_user_id from `channel` where channel_name= '". $_POST["userId"] ."' limit 1;");
        $id = $id->fetch();
        $videoPath="test";
        $videoTime = "time";
        $query = "INSERT INTO `videos`(`title`, `date`, `channel_id`, `video_path`, `video_time`) VALUES ('". $title ."', '". $dateUploaded ."', '". $id["channel_user_id"] ."','". $videoPath ."', '". $videoTime ."')";
        $db->exec($query);
        $folderName = $db->lastInsertId();
        $ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        $filenamewithoutextension = pathinfo($file_name, PATHINFO_FILENAME);
        if (!file_exists('../uploads/'.$_POST["userId"].'/'.$folderName)) {
            mkdir('../uploads/'.$_POST["userId"].'/'.$folderName, 0777);
        }
        $filename_to_store = $filenamewithoutextension. '_' .uniqid(). '.' .$ext;
        move_uploaded_file($_FILES['file']['tmp_name'][$key], '../uploads/'.$_POST["userId"]. '/'.$folderName.'/'.$filename_to_store);
        $dateUploaded = date("Y F d", filemtime('../uploads/'.$_POST["userId"]. '/'.$folderName.'/'.$filename_to_store));
        $title = $filenamewithoutextension;
        $videoPath = '../uploads/'.$_POST["userId"]. '/'.$folderName.'/'.$filename_to_store;
        $row = $db->query("select channel_user_id from `channel` where channel_name= '". $_POST["userId"] ."' limit 1;");
        $row = $row->fetch();
        $id = (int) $row["channel_user_id"];
        list($year, $month, $day) = explode(" ", $dateUploaded);
        $date = $month." ".$day." ".$year;
        $dateUploaded =  date('Y/m/d', strtotime($date));
        $getID3 = new getID3;
        $file = $getID3->analyze($videoPath);
        $videoTime = $file['playtime_string'];
        $query = "UPDATE `videos` set `title`='". $title ."', `date`='". $dateUploaded ."', `channel_id`='". $id ."', `video_path`= '". $videoPath ."', `video_time`='". $videoTime ."' where `video_id`= $folderName";
        $db->exec($query);
    }

?>