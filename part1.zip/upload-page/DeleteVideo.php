<?php
    include("../database-connection/connect.php");
    if (isset($_REQUEST["videoId"])) {
        $id = $_REQUEST["videoId"];
        $videoDetails = $db->query("SELECT `dislikes`, `title`, `likes`, `description`, `date`, `video_id`, `channel_id`, `video_path`, `views` FROM `videos` WHERE `video_id`=$id;");
        $videoDetails = $videoDetails->fetch();
        $videoPath = $videoDetails["video_path"];
        list($v1, $v2, $v3, $v4, $v5) = explode("/", $videoPath);
        $x=$v1."/".$v2."/".$v3."/".$v4."/".$v5;
        
        $y = $v1."/".$v2."/".$v3."/".$v4;
        $z = '../MainPage/thumbnails/image'.$id.'.jpg';
        if (unlink($x)) {
           if (rmdir($y)) {
               unlink($z);
                $db->exec("DELETE FROM `videos` where `video_id`= $id;");
                header("Location: upload-video-page.php");
           }
        }
    }
?>
