<?php
    if (isset($_POST["private"])) {
        include("../database-connection/connect.php");
        $id = $_POST["private"];
        $db->exec("UPDATE `videos` SET `show` = 0 where `video_id` = $id;");
    }


?>